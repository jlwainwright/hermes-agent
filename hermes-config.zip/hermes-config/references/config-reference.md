# Hermes Config Reference

Complete field-level reference for `~/.hermes/config.yaml`. Source: `hermes_cli/config.py` DEFAULT_CONFIG.

## model

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| (top-level) | str | `"anthropic/claude-opus-4.6"` | Provider/model string (e.g. `"anthropic/claude-opus-4.6"`, `"openrouter/google/gemini-3-flash-preview"`) |
| api_key | str | `""` | API key for the provider |
| base_url | str | `""` | Custom API endpoint URL |
| default | str | `""` | Default model alias (e.g. `"kilocode:"`) |
| provider | str | `""` | Provider name: nous-portal, openai-codex, anthropic, openrouter, zhipu, kimi, minimax, minimax-cn, dashscope, kilocode, opencode-zen, opencode-go, vercel-ai-gateway, custom |

## toolsets

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| (list) | list | `["hermes-cli"]` | List of tool groups. Use `[- all]` to enable everything |

## agent

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| max_turns | int | `90` | Max tool-calling iterations per conversation |
| personalities | dict | `{}` | Named personality system prompts (string or dict with description/system_prompt/tone/style) |
| personality | str | `""` | Active personality name (empty = none) |
| reasoning_effort | str | `"medium"` | Reasoning effort level |
| system_prompt | str | `""` | Additional system prompt text |
| verbose | bool | `false` | Verbose output mode |

## terminal

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| backend | str | `"local"` | Terminal backend: local, docker, ssh, daytona, modal, singularity |
| cwd | str | `"."` | Working directory for commands |
| timeout | int | `180` | Command timeout in seconds |
| env_passthrough | list | `[]` | Env vars to pass to sandboxed execution |
| docker_image | str | `"nikolaik/python-nodejs:python3.11-nodejs20"` | Docker image for container backends |
| docker_forward_env | list | `[]` | Env vars to forward into Docker containers |
| singularity_image | str | `"docker://nikolaik/python-nodejs:python3.11-nodejs20"` | Singularity image |
| modal_image | str | `"nikolaik/python-nodejs:python3.11-nodejs20"` | Modal image |
| daytona_image | str | `"nikolaik/python-nodejs:python3.11-nodejs20"` | Daytona image |
| container_cpu | int | `1` | CPU cores for containers |
| container_memory | int | `5120` | RAM in MB for containers (5GB) |
| container_disk | int | `51200` | Disk in MB for containers (50GB) |
| container_persistent | bool | `true` | Persist filesystem across sessions |
| docker_volumes | list | `[]` | Docker volume mounts ("host:container") |
| docker_mount_cwd_to_workspace | bool | `false` | Mount host cwd into /workspace |
| persistent_shell | bool | `true` | Keep long-lived bash shell across commands |
| lifetime_seconds | int | `300` | Container lifetime before cleanup |

## browser

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| inactivity_timeout | int | `120` | Seconds before browser closes from inactivity |
| command_timeout | int | `30` | Timeout for browser commands (screenshot, navigate, etc.) |
| record_sessions | bool | `false` | Auto-record browser sessions as WebM videos |

## checkpoints

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| enabled | bool | `true` | Enable filesystem snapshots before destructive ops |
| max_snapshots | int | `50` | Max checkpoints per directory |

## compression

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| enabled | bool | `true` | Enable context compression |
| threshold | float | `0.50` | Compress when context usage exceeds this ratio |
| target_ratio | float | `0.20` | Fraction of threshold to preserve as recent tail |
| protect_last_n | int | `20` | Minimum recent messages to keep uncompressed |
| summary_model | str | `""` | Model for summaries (empty = use main model) |
| summary_provider | str | `"auto"` | Provider for summary model |
| summary_base_url | str/null | `null` | Custom endpoint for summary model |

## smart_model_routing

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| enabled | bool | `false` | Route simple queries to a cheaper model |
| max_simple_chars | int | `160` | Max character length for "simple" queries |
| max_simple_words | int | `28` | Max word count for "simple" queries |
| cheap_model | dict | `{}` | Provider/model config for the cheap model |

## auxiliary

Each auxiliary task has: provider, model, base_url, api_key. All default to "auto"/"".

| Task | Purpose | Notes |
|------|---------|-------|
| vision | Image analysis | Falls back to openrouter:gemini-flash |
| web_extract | Web page content extraction | |
| compression | Context compression summaries | |
| session_search | Cross-session search | |
| skills_hub | Skills hub queries | |
| approval | Smart approval decisions | Fast/cheap model recommended |
| mcp | MCP tool routing | |
| flush_memories | Memory flush processing | |

Timeout for vision auxiliary: 30s (configurable).

## display

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| compact | bool | `false` | Compact display mode |
| personality | str | `"kawaii"` | Default personality for display |
| resume_display | str | `"full"` | How much context to show on resume: full, summary, none |
| bell_on_complete | bool | `false` | Terminal bell when agent completes |
| show_reasoning | bool | `false` | Show model reasoning/thinking |
| streaming | bool | `false` | Stream tokens in real-time |
| show_cost | bool | `false` | Show $ cost in status bar |
| skin | str | `"default"` | UI skin/theme |
| theme_mode | str | `"auto"` | Theme: auto, light, dark |
| tool_progress | str | `"all"` | Tool progress: off, new, all, verbose |
| background_process_notifications | str | `"all"` | Background process notifications |

## privacy

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| redact_pii | bool | `false` | Hash user IDs and strip phone numbers from LLM context |

## tts

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| provider | str | `"edge"` | TTS provider: edge, elevenlabs, openai, neutts |
| edge.voice | str | `"en-US-AriaNeural"` | Edge TTS voice. Options: AriaNeural, JennyNeural, AndrewNeural, BrianNeural, SoniaNeural |
| elevenlabs.voice_id | str | `"pNInz6obpgDQGcFmaJgB"` | ElevenLabs voice ID (Adam) |
| elevenlabs.model_id | str | `"eleven_multilingual_v2"` | ElevenLabs model |
| openai.model | str | `"gpt-4o-mini-tts"` | OpenAI TTS model |
| openai.voice | str | `"alloy"` | OpenAI TTS voice. Options: alloy, echo, fable, onyx, nova, shimmer |
| neutts.ref_audio | str | `""` | Path to reference voice audio (empty = bundled default) |
| neutts.ref_text | str | `""` | Path to reference voice transcript |
| neutts.model | str | `"neuphonic/neutts-air-q4-gguf"` | HuggingFace model repo |
| neutts.device | str | `"cpu"` | Device: cpu, cuda, mps |

## stt

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| enabled | bool | `true` | Enable speech-to-text |
| provider | str | `"local"` | STT provider: local, groq, openai |
| local.model | str | `"base"` | Whisper model: tiny, base, small, medium, large-v3 |
| openai.model | str | `"whisper-1"` | OpenAI Whisper model. Options: whisper-1, gpt-4o-mini-transcribe, gpt-4o-transcribe |

## voice

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| record_key | str | `"ctrl+b"` | Key combo to start recording |
| max_recording_seconds | int | `120` | Max recording length |
| auto_tts | bool | `false` | Auto-speak replies |
| silence_threshold | int | `200` | RMS below this = silence (0-32767) |
| silence_duration | float | `3.0` | Seconds of silence before auto-stop |

## human_delay

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| mode | str | `"off"` | Simulate human typing delay: off, fixed, variable |
| min_ms | int | `800` | Min delay in ms |
| max_ms | int | `2500` | Max delay in ms |

## memory

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| memory_enabled | bool | `true` | Enable persistent memory |
| user_profile_enabled | bool | `true` | Enable user profile memory |
| memory_char_limit | int | `2200` | ~800 tokens at 2.75 chars/token |
| user_char_limit | int | `1375` | ~500 tokens at 2.75 chars/token |
| flush_min_turns | int | `6` | Min turns before flushing memories |
| nudge_interval | int | `10` | Turns between memory nudges |

## delegation

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| model | str | `""` | Model for subagents (empty = inherit parent) |
| provider | str | `""` | Provider for subagents (empty = inherit parent) |
| base_url | str | `""` | Custom endpoint for subagents |
| api_key | str | `""` | API key for delegation endpoint |
| default_toolsets | list | `["terminal", "file", "web"]` | Toolsets available to subagents |
| max_iterations | int | `50` | Max iterations per subagent |

## honcho

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| (dict) | dict | `{}` | Hermes-specific Honcho overrides. Main config in ~/.honcho/config.json |

## timezone

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| (str) | str | `""` | IANA timezone (e.g. "Africa/Johannesburg", "America/New_York"). Empty = server-local |

## discord

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| require_mention | bool | `true` | Require @mention in server channels |
| free_response_channels | str | `""` | Comma-separated channel IDs for free response |
| auto_thread | bool | `true` | Auto-create threads on @mention |

## whatsapp

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| (dict) | dict | `{}` | Reply prefix config. Supports \n for newlines |

## approvals

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| mode | str | `"manual"` | Approval mode: manual, smart, off |

## command_allowlist

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| (list) | list | `[]` | Permanently allowed dangerous command patterns |

## quick_commands

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| (dict) | dict | `{}` | User-defined quick commands (type: exec only) |

## personalities

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| (dict) | dict | `{}` | Custom personality definitions. String or dict format |

## security

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| redact_secrets | bool | `true` | Redact secrets in output |
| tirith_enabled | bool | `true` | Enable Tirith pre-exec security scanning |
| tirith_path | str | `"tirith"` | Path to tirith binary |
| tirith_timeout | int | `5` | Tirith scan timeout in seconds |
| tirith_fail_open | bool | `true` | Allow command if scanner fails |
| website_blocklist.enabled | bool | `false` | Enable website domain blocking |
| website_blocklist.domains | list | `[]` | Blocked domains |
| website_blocklist.shared_files | list | `[]` | Shared blocklist files |

## code_execution

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| max_tool_calls | int | `50` | Max tool calls per code execution |
| timeout | int | `300` | Code execution timeout in seconds |

## mcp_servers

Each server entry:

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| command | str | required | Executable to run |
| args | list | `[]` | Arguments |
| env | dict | `{}` | Environment variables |
| timeout | int | `60` | Server timeout in seconds |
| connect_timeout | int | `30` | Connection timeout in seconds |

## platform_toolsets

Per-platform tool lists. Each platform is a list of tool group names.

Platforms: cli, discord, telegram, slack, whatsapp, signal, homeassistant

## session_reset

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| at_hour | int | `5` | Hour of day to reset sessions (24h) |
| idle_minutes | int | `1440` | Minutes of inactivity before reset (1440 = 24h) |
| mode | str | `"both"` | Reset mode: both, hourly, idle |

## skills

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| creation_nudge_interval | int | `15` | Turns between skill creation nudges |

## skills_hub

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| base_path | str | `"~/.agents/skills"` | Base path for installed skills |

## streaming

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| enabled | bool | `false` | Enable response streaming |

## group_sessions_per_user

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| (bool) | bool | `true` | Group sessions per user in gateway mode |
