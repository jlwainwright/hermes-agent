# Hermes Environment Variables

All env vars are set in `~/.hermes/.env`. Config version 10.

## Provider Keys

| Var | Description | URL |
|-----|-------------|-----|
| OPENAI_API_KEY | OpenAI API key | platform.openai.com/api-keys |
| OPENAI_BASE_URL | OpenAI base URL override | |
| OPENROUTER_API_KEY | OpenRouter (vision, web scraping, MoA) | openrouter.ai/keys |
| OPENROUTER_MANAGEMENT_KEY | OpenRouter management key for guardrails/key management (separate from regular API key; has `is_management_key: true`) | openrouter.ai/keys |
| ANTHROPIC_API_KEY | Anthropic API key | |
| ANTHROPIC_TOKEN | Anthropic auth token (Claude Code) | |
| GLM_API_KEY | Z.AI / GLM (also ZAI_API_KEY, Z_AI_API_KEY) | z.ai |
| GLM_BASE_URL | Z.AI / GLM base URL override | |
| KIMI_API_KEY | Kimi / Moonshot | platform.moonshot.cn |
| KIMI_BASE_URL | Kimi base URL override | |
| MINIMAX_API_KEY | MiniMax (international) | minimax.io |
| MINIMAX_BASE_URL | MiniMax base URL override | |
| MINIMAX_CN_API_KEY | MiniMax (China) | minimaxi.com |
| MINIMAX_CN_BASE_URL | MiniMax China base URL override | |
| DEEPSEEK_API_KEY | DeepSeek | platform.deepseek.com/api_keys |
| DEEPSEEK_BASE_URL | DeepSeek base URL | |
| DASHSCOPE_API_KEY | Alibaba Cloud DashScope (Qwen) | modelstudio.console.alibabacloud.com |
| DASHSCOPE_BASE_URL | DashScope base URL | |
| OPENCODE_ZEN_API_KEY | OpenCode Zen (pay-as-you-go) | opencode.ai/auth |
| OPENCODE_ZEN_BASE_URL | OpenCode Zen base URL | |
| OPENCODE_GO_API_KEY | OpenCode Go ($10/mo subscription) | opencode.ai/auth |
| OPENCODE_GO_BASE_URL | OpenCode Go base URL | |
| NOUS_BASE_URL | Nous Portal base URL override | |

## Tool API Keys

| Var | Description | Tools Enabled |
|-----|-------------|---------------|
| PARALLEL_API_KEY | AI-native web search and extract | web_search, web_extract |
| FIRECRAWL_API_KEY | Web search and scraping | web_search, web_extract |
| FIRECRAWL_API_URL | Self-hosted Firecrawl URL | |
| TAVILY_API_KEY | AI-native web search, extract, crawl | web_search, web_extract, web_crawl |
| BROWSERBASE_API_KEY | Cloud browser | browser_navigate, browser_click |
| BROWSERBASE_PROJECT_ID | Browserbase project | |
| BROWSER_USE_API_KEY | Cloud browser via browser-use.com | browser_navigate, browser_click |
| FAL_KEY | Image generation | image_generate |
| TINKER_API_KEY | RL training | rl_start_training, rl_check_status, rl_stop_training |
| WANDB_API_KEY | Experiment tracking | rl_get_results, rl_check_status |
| VOICE_TOOLS_OPENAI_KEY | Whisper STT + OpenAI TTS | voice_transcription, openai_tts |
| ELEVENLABS_API_KEY | Premium TTS voices | |
| GITHUB_TOKEN | Skills Hub (higher rate limits, publish) | |
| HONCHO_API_KEY | AI-native persistent memory | honcho_context |
| HONCHO_BASE_URL | Self-hosted Honcho | |
| GOOGLE_API_KEY | Google services | |

## Messaging Platforms

| Var | Description |
|-----|-------------|
| TELEGRAM_BOT_TOKEN | Telegram bot (from @BotFather) |
| TELEGRAM_ALLOWED_USERS | Comma-separated user IDs |
| TELEGRAM_HOME_CHANNEL | Telegram home channel |
| DISCORD_BOT_TOKEN | Discord bot (Developer Portal) |
| DISCORD_ALLOWED_USERS | Comma-separated Discord user IDs |
| DISCORD_HOME_CHANNEL | Discord home channel |
| SLACK_BOT_TOKEN | Slack bot (xoxb-) |
| SLACK_APP_TOKEN | Slack app token (xapp-) for Socket Mode |
| SLACK_ALLOWED_USERS | Allowed Slack users |
| WHATSAPP_ENABLED | Enable WhatsApp platform |
| WHATSAPP_MODE | WhatsApp mode |
| WHATSAPP_ALLOWED_USERS | Allowed WhatsApp users |
| SIGNAL_ACCOUNT | Signal account number |
| SIGNAL_HTTP_URL | Signal HTTP API URL |
| SIGNAL_ALLOWED_USERS | Allowed Signal users |
| SIGNAL_GROUP_ALLOWED_USERS | Allowed Signal group IDs |
| MATRIX_HOMESERVER | Matrix homeserver URL |
| MATRIX_ACCESS_TOKEN | Matrix access token |
| MATRIX_USER_ID | Matrix user ID (@user:server) |
| MATRIX_PASSWORD | Matrix password login |
| MATRIX_ENCRYPTION | Matrix encryption |
| MATRIX_HOME_ROOM | Matrix home room |
| MATTERMOST_URL | Mattermost server URL |
| MATTERMOST_TOKEN | Mattermost bot token |
| MATTERMOST_ALLOWED_USERS | Allowed Mattermost users |
| MATTERMOST_HOME_CHANNEL | Mattermost home channel |
| MATTERMOST_REPLY_MODE | Mattermost reply mode |
| DINGTALK_CLIENT_ID | DingTalk client ID |
| DINGTALK_CLIENT_SECRET | DingTalk client secret |
| GATEWAY_ALLOW_ALL_USERS | Allow all users (true/false) |

## Server / API

| Var | Description |
|-----|-------------|
| API_SERVER_ENABLED | Enable OpenAI-compatible API server (true/false) |
| API_SERVER_KEY | Bearer token for API server auth |
| API_SERVER_PORT | API server port (default: 8642) |
| API_SERVER_HOST | Bind address (default: 127.0.0.1; use 0.0.0.0 for network) |
| WEBHOOK_ENABLED | Enable webhook platform (GitHub, GitLab, etc.) |
| WEBHOOK_PORT | Webhook port (default: 8644) |
| WEBHOOK_SECRET | HMAC secret for webhook signature validation |

## Agent Settings

| Var | Description |
|-----|-------------|
| MESSAGING_CWD | Working directory for terminal commands via messaging |
| SUDO_PASSWORD | Sudo password for root access commands |
| HERMES_MAX_ITERATIONS | Max tool-calling iterations (default: 90) |
| HERMES_PREFILL_MESSAGES_FILE | Path to JSON prefill messages file |
| HERMES_EPHEMERAL_SYSTEM_PROMPT | Ephemeral system prompt (never persisted) |

## Terminal

| Var | Description |
|-----|-------------|
| TERMINAL_ENV | Additional env vars for terminal |
| TERMINAL_SSH_KEY | SSH key path for remote terminal |
| TERMINAL_SSH_PORT | SSH port for remote terminal |
| TERMINAL_TIMEOUT | Terminal command timeout |
| TERMINAL_LIFETIME_SECONDS | Container lifetime |
| TERMINAL_MODAL_IMAGE | Modal image override |

## Debug (optional)

| Var | Description |
|-----|-------------|
| WEB_TOOLS_DEBUG | Debug web tools |
| VISION_TOOLS_DEBUG | Debug vision tools |
| MOA_TOOLS_DEBUG | Debug mixture-of-agents |
| IMAGE_TOOLS_DEBUG | Debug image tools |
| BROWSER_SESSION_TIMEOUT | Browser session timeout |
| BROWSER_INACTIVITY_TIMEOUT | Browser inactivity timeout |
| BROWSERBASE_PROXIES | Browserbase proxy config |
| BROWSERBASE_ADVANCED_STEALTH | Browserbase stealth mode |

## Home Assistant

| Var | Description |
|-----|-------------|
| HASS_URL | Home Assistant URL |
| HASS_TOKEN | Home Assistant long-lived access token |
