---
name: hermes-config
description: Configure, optimize, and troubleshoot Hermes Agent by NousResearch. Covers config.yaml settings, provider setup, toolsets, MCP servers, messaging platforms, voice mode, memory, skills, delegation, compression, security, cron, and all env vars. Use when setting up Hermes, changing config, diagnosing issues, or enabling new features.
---

# Hermes Agent Configuration

Hermes Agent is installed at `~/.hermes/`. The main config file is `~/.hermes/config.yaml`. API keys live in `~/.hermes/.env` (never committed to git).

To apply config changes, edit `~/.hermes/config.yaml` directly or use `hermes config set <key> <value>`.

## Quick Reference

| Command | Purpose |
|---------|---------|
| `hermes` | Start chatting |
| `hermes model` | Switch LLM provider/model |
| `hermes tools` | Configure toolsets per platform |
| `hermes setup` | Full setup wizard |
| `hermes doctor` | Diagnose issues |
| `hermes update` | Update Hermes |
| `hermes gateway` | Start messaging gateway |
| `hermes -c` | Resume last session |
| `hermes skills search <q>` | Search skills hub |
| `hermes skills install <id>` | Install a skill |

## Config Structure

The config file has these top-level sections. See `references/config-reference.md` for every field, its type, default, and description.

- **model** — provider, API key, base URL, default model
- **toolsets** — which tool groups are active (use `- all` for everything)
- **agent** — max_turns, personalities, personality, reasoning_effort, system_prompt, verbose
- **terminal** — backend (local/docker/ssh/daytona/modal/singularity), timeout, container settings
- **browser** — inactivity_timeout, command_timeout, record_sessions
- **checkpoints** — enabled, max_snapshots (rollback support)
- **compression** — enabled, threshold, target_ratio, summary model
- **smart_model_routing** — route simple queries to cheaper models
- **auxiliary** — per-task model overrides (vision, web_extract, compression, session_search, skills_hub, approval, mcp, flush_memories)
- **display** — compact, personality, resume_display, bell_on_complete, show_reasoning, streaming, show_cost, skin, theme_mode, tool_progress, background_process_notifications
- **privacy** — redact_pii
- **tts** — provider (edge/elevenlabs/openai/neutts), voice config per provider
- **stt** — enabled, provider (local/groq/openai), model
- **voice** — record_key, max_recording_seconds, auto_tts, silence_threshold, silence_duration
- **human_delay** — mode, min_ms, max_ms
- **memory** — memory_enabled, user_profile_enabled, memory_char_limit, user_char_limit, flush_min_turns, nudge_interval
- **delegation** — model, provider, base_url, api_key for subagents
- **honcho** — AI-native persistent memory (reads from ~/.honcho/config.json)
- **timezone** — IANA timezone string
- **discord** — require_mention, free_response_channels, auto_thread
- **whatsapp** — reply prefix config
- **approvals** — mode (manual/smart/off), command_allowlist
- **quick_commands** — user-defined shortcuts
- **personalities** — custom personality definitions
- **security** — redact_secrets, tirith_enabled, website_blocklist
- **code_execution** — max_tool_calls, timeout
- **mcp_servers** — MCP server definitions
- **platform_toolsets** — per-platform tool lists (cli, discord, telegram, slack, whatsapp, signal, homeassistant)
- **session_reset** — at_hour, idle_minutes, mode
- **skills** — creation_nudge_interval
- **skills_hub** — base_path
- **streaming** — enabled

## Providers

| Provider | Setup | Config Key |
|----------|-------|------------|
| Nous Portal | OAuth via `hermes model` | provider: nous-portal |
| OpenAI Codex | Device code auth via `hermes model` | provider: openai-codex |
| Anthropic | API key or Claude Code auth | provider: anthropic |
| OpenRouter | Enter API key | provider: openrouter |
| Z.AI / GLM | Set GLM_API_KEY | provider: zhipu |
| Kimi / Moonshot | Set KIMI_API_KEY | provider: kimi |
| MiniMax | Set MINIMAX_API_KEY | provider: minimax |
| MiniMax China | Set MINIMAX_CN_API_KEY | provider: minimax-cn |
| Alibaba Cloud | Set DASHSCOPE_API_KEY | provider: dashscope |
| Kilo Code | Set KILOCODE_API_KEY | provider: kilocode |
| OpenCode Zen | Set OPENCODE_ZEN_API_KEY | provider: opencode-zen |
| OpenCode Go | Set OPENCODE_GO_API_KEY | provider: opencode-go |
| Vercel AI Gateway | Set AI_GATEWAY_API_KEY | provider: vercel-ai-gateway |
| Custom Endpoint | Set base_url + api_key | provider: custom |

## Toolsets (built-in)

Available tool groups: browser, clarify, code_execution, cronjob, delegation, file, hermes-cli, homeassistant, image_gen, memory, rl, session_search, skills, terminal, todo, tts, vision, web

Enable all with `toolsets: [- all]` in config.yaml.

## Messaging Platforms

Configure via `hermes gateway setup` or env vars:

| Platform | Required Env Vars |
|----------|-------------------|
| Telegram | TELEGRAM_BOT_TOKEN, TELEGRAM_ALLOWED_USERS |
| Discord | DISCORD_BOT_TOKEN, DISCORD_ALLOWED_USERS |
| Slack | SLACK_BOT_TOKEN, SLACK_APP_TOKEN |
| WhatsApp | WHATSAPP_ENABLED |
| Signal | SIGNAL_ACCOUNT, SIGNAL_HTTP_URL |
| Home Assistant | HASS_URL, HASS_TOKEN |
| Matrix | MATRIX_HOMESERVER, MATRIX_ACCESS_TOKEN, MATRIX_USER_ID |
| Mattermost | MATTERMOST_URL, MATTERMOST_TOKEN |
| Email | (built-in, no extra config) |

## OpenRouter Guardrails

OpenRouter supports guardrails to restrict which models API keys can access. Requires a **management key** (regular API keys have `is_management_key: false`).

### API Endpoints

| Method | Endpoint | Purpose |
|--------|----------|---------|
| GET | `/api/v1/guardrails` | List all guardrails |
| POST | `/api/v1/guardrails` | Create a guardrail |
| PATCH | `/api/v1/guardrails/{id}` | Update a guardrail |
| DELETE | `/api/v1/guardrails/{id}` | Delete a guardrail |
| GET | `/api/v1/guardrails/{id}/assignments/keys` | List key assignments |
| POST | `/api/v1/guardrails/{id}/assignments/keys` | Assign keys to guardrail |
| POST | `/api/v1/guardrails/{id}/assignments/keys/remove` | Unassign keys |
| GET | `/api/v1/keys` | List all API keys (management only) |
| GET | `/api/v1/key` | Get current key info (works with any key) |

### Creating a Guardrail

```bash
# Create guardrail (use management key)
curl -X POST https://openrouter.ai/api/v1/guardrails \
  -H "Authorization: Bearer $MANAGEMENT_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Free Models Only",
    "description": "Block all paid models",
    "allowed_models": [
      "stepfun/step-3.5-flash:free",
      "nvidia/nemotron-3-super-120b-a12b:free",
      "nvidia/nemotron-nano-12b-v2-vl:free"
    ]
  }'

# Assign keys to guardrail (use key hashes from GET /api/v1/keys)
curl -X POST https://openrouter.ai/api/v1/guardrails/{id}/assignments/keys \
  -H "Authorization: Bearer $MANAGEMENT_KEY" \
  -H "Content-Type: application/json" \
  -d '{"key_hashes": ["hash1", "hash2"]}'
```

### Guardrail Schema

| Field | Type | Description |
|-------|------|-------------|
| name | string (required) | Guardrail name |
| description | string? | Description |
| limit_usd | number? | Spending limit in USD |
| reset_interval | string? | `daily`, `weekly`, `monthly` |
| allowed_providers | string[]? | Provider IDs to whitelist |
| ignored_providers | string[]? | Provider IDs to exclude |
| allowed_models | string[]? | Model slugs to whitelist (accepts both slug and canonical_slug) |
| enforce_zdr | boolean? | Enforce zero data retention |

### Checking Key Type

```bash
# Any key can check its own type
curl https://openrouter.ai/api/v1/key \
  -H "Authorization: Bearer $KEY"
# Look for "is_management_key": true
```

### Free Models (fetch current list)

```bash
curl -s https://openrouter.ai/api/v1/models | python3 -c "
import json, sys
data = json.load(sys.stdin)
free = [m['id'] for m in data['data'] if ':free' in m['id']]
print('\n'.join(sorted(free)))
"
```

### OpenRouter API Key Types

- **Regular API key** (`is_management_key: false`) — Can call `/api/v1/key`, `/api/v1/chat/completions`, `/api/v1/models`
- **Management key** (`is_management_key: true`) — Additionally can manage keys and guardrails via `/api/v1/keys`, `/api/v1/guardrails`
- **Provisioning key** (`is_provisioning_key: true`) — Can create new API keys programmatically

### Hermes OpenRouter Integration

When using OpenRouter as the provider for auxiliary tasks (vision, compression, delegation, approval, etc.), set in config.yaml:

```yaml
auxiliary:
  vision:
    provider: openrouter
    model: nvidia/nemotron-nano-12b-v2-vl:free
  approval:
    provider: openrouter
    model: stepfun/step-3.5-flash:free
compression:
  summary_model: stepfun/step-3.5-flash:free
  summary_provider: openrouter
delegation:
  provider: openrouter
  model: nvidia/nemotron-3-super-120b-a12b:free
```

## MCP Servers

Add to `mcp_servers` in config.yaml:

```yaml
mcp_servers:
  server_name:
    command: <executable>
    args: [<arg1>, <arg2>]
    env:
      KEY: value
    timeout: 60
    connect_timeout: 30
```

## Environment Variables

See `references/env-vars.md` for the complete list with descriptions, categories, and which tools each var enables.

## Optimization Checklist

When setting up or auditing Hermes, verify these items:

1. **Timezone set** — `timezone` in config.yaml (e.g. `Africa/Johannesburg`). Affects cron and scheduling.
2. **Smart model routing** — Enable `smart_model_routing.enabled: true` and set a cheap model to save cost on simple queries.
3. **Approval mode** — Consider `smart` instead of `manual` for auto-approving low-risk commands.
4. **Delegation model** — Set a cheaper model for subagents (delegation section) to reduce cost on parallel tasks.
5. **Streaming enabled** — Set `display.streaming: true` for real-time token output.
6. **Cost tracking** — Set `display.show_cost: true` to see $ per message.
7. **Compression tuned** — Default threshold is 0.50 (compress at 50% context). Higher values wait longer. Adjust based on model context window.
8. **Auxiliary models configured** — Each auxiliary task (vision, web_extract, etc.) can use a cheaper model. Leaving as "auto" is fine if API keys are set.
9. **Browser session recording** — Set `browser.record_sessions: true` for debugging.
10. **Privacy** — Set `privacy.redact_pii: true` if handling sensitive user data.
11. **Checkpoints** — Ensure enabled for `/rollback` support.
12. **STT model** — `base` is fastest; upgrade to `small` or `medium` for better accuracy.
13. **TTS provider** — Edge is free, ElevenLabs is premium quality.
14. **NeuTTS device** — Use `mps` on Apple Silicon, `cuda` on NVIDIA, `cpu` otherwise.
15. **Website blocklist** — Enable `security.website_blocklist.enabled: true` and add domains if restricting browser access.
16. **OpenRouter guardrails** — Set guardrails with `allowed_models` whitelist to prevent accidental paid model usage. Use management key (not regular API key).
17. **OpenRouter management key** — Regular API keys cannot manage guardrails or list keys. Ensure a management key is available (separate from `OPENROUTER_API_KEY`).

## Identity Files

- `~/.hermes/IDENTITY.md` — Agent name, role, avatar
- `~/.hermes/SOUL.md` — Agent personality, operating principles, communication style
- These are injected into the system prompt on every session start

## Session Management

- `hermes -c` — Resume last session
- `hermes --continue` — Same as above
- Session reset: controlled by `session_reset` config (at_hour, idle_minutes, mode)
- Sessions stored in `~/.hermes/sessions/`

## Skills System

- Skills are stored in `~/.hermes/skills/`
- Install: `hermes skills install <id>`
- Search: `hermes skills search <query> [--source skills-sh] [--source well-known]`
- Create: Skills follow agentskills.io format
- Skills can bundle tools, prompts, and configuration

## Common Issues

- **"context length exceeded"** — Lower compression threshold or switch to a model with a larger context window
- **MCP server timeout** — Increase `timeout` in mcp_servers config
- **Browser not working** — Ensure playwright dependencies installed: `playwright install chromium`
- **Voice not working** — Ensure `pip install "hermes-agent[voice]"` and `pip install faster-whisper`
- **Gateway not starting** — Run `hermes doctor` to diagnose
